import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';

interface PhotoInterface {
  albumId: number,
  id: number,
  title: String,
  url: String,
  thumbnailUrl: String,
}

@Component({
  selector: 'app-tab4',
  templateUrl: './tab4.page.html',
  styleUrls: ['./tab4.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule]
})

export class Tab4Page implements OnInit {

  constructor() { }

  private url: RequestInfo = 'https://jsonplaceholder.typicode.com/albums/1/photos';
  // https://equran.id/api/v2/imsakiyah/jadwal
  // {"provinsi":"D.I. Yogyakarta", "kabKota": "Kab. Sleman"}
  public photos!: Array<PhotoInterface>;

  ngOnInit(): void {
    fetch(this.url)
      .then((response) => response.json())
      .then((data) => (this.photos = data));
  }

}
