export const MATCH = {
    events: [
        {
            idEvent: '602445',
            strHomeTeam: 'Everton',
            strAwayTeam: 'Leicester',
            dateEvent: '2020-04-06',
            dateEventLocal: '2020-04-06',
            strDate: '06\/04\/20',
            strTime: '19:00:00',
        },
        {
            idEvent: '602446',
            strHomeTeam: 'Man City',
            strAwayTeam: 'Liverpool',
            dateEvent: '2020-04-05',
            dateEventLocal: null,
            strDate: '05\/04\/20',
            strTime: '15:30:00',
        },
        {

            idEvent: '602442',
            strHomeTeam: 'West Ham',
            strAwayTeam: 'Chelsea',
            dateEvent: '2020-04-05',
            dateEventLocal: null,
            strDate: '05\/04\/20',
            strTime: '13:00:00',
        },
        {
            idEvent: '602448',
            strHomeTeam: 'Sheffield United',
            strAwayTeam: 'Tottenham',
            dateEvent: '2020-04-04',
            dateEventLocal: null,
            strDate: '04\/04\/20',
            strTime: '16:30:00',
        }
    ]
}; 