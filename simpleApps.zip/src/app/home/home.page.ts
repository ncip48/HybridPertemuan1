import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage implements OnInit {
  public nama: string | undefined;
  alamat: string | undefined;
  kelas: string | undefined;
  bod: string | undefined;

  constructor() {
    
  }

  ngOnInit(): void {
    this.nama = "Herly";
    this.alamat = "Jl Trunojoyo";
    this.kelas = "D3TI01";
    this.bod = "15/05/1999";
  }

}
