import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { isEmpty } from 'rxjs';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage implements OnInit {
  todo: any = {};
  todos: any = [];
  public nama: string | undefined;
  alamat: string | undefined;
  kelas: string | undefined;
  bod: string | undefined;

  constructor(private route: Router) {

  }

  ngOnInit(): void {
    this.nama = "Herly";
    this.alamat = "Jl Trunojoyo";
    this.kelas = "D3TI01";
    this.bod = "15/05/1999";
  }

  saveData() {
    // console.log(this.todo);
    this.todos.push(this.todo)
    console.log(this.todos);
  }
  
  scorePage() {
    this.route.navigate(['/score']);
  }
}
